package com.fbip.firebase_impl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
